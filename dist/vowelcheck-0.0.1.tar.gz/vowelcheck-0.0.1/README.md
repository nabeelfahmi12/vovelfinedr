						# Description #
# Vowel Check
This program check whether the inputed sting is a vowel or not.

# How to Install the package
run the following command to install :
pip install vowelcheck

# Usage 
from vowelcheck import vowel_check

1. vowel_check("a")

2. a = "s"
   vowel_check(a)
  
GitHub Repostry:

To check the sourse code: https://github.com/nabeelfahmi12/pypi_vowel_check